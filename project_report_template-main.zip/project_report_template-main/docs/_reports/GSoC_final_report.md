[Link to slideshow](https://docs.google.com/presentation/d/e/2PACX-1vTNZ3ZSoYJIIugGxr8AeeQhXI6cgB3je_nD2R1IwVf589H9NRhCIN_L4ZDGS2meLg/pub?start=false&loop=false&delayms=3000)

![Final Report of GSoC pptx](https://user-images.githubusercontent.com/8393063/189002570-47108926-6ed3-4b62-966e-1afe5a81ef38.jpg)

![Final Report of GSoC pptx (10)](https://user-images.githubusercontent.com/8393063/189555900-283b4c5b-5c44-4c1c-b0c3-6ec5824a4598.jpg)

![Final Report of GSoC pptx (12)](https://user-images.githubusercontent.com/8393063/189556101-079b21a8-f99a-4c00-b0b7-38a11d7908e8.jpg)

![Final Report of GSoC pptx (3)](https://user-images.githubusercontent.com/8393063/189002712-280e1378-5c29-445a-b87e-40ec503ea315.jpg)

![Final Report of GSoC pptx (4)](https://user-images.githubusercontent.com/8393063/189002800-4e4c45cd-29a4-4e10-9ae4-3e5d428e4575.jpg)

![Final Report of GSoC pptx (5)](https://user-images.githubusercontent.com/8393063/189002921-1fe2a9ff-9a8a-498b-a21c-69eda86da2bf.jpg)

![Final Report of GSoC pptx (6)](https://user-images.githubusercontent.com/8393063/189003056-e247e947-7340-4399-9c46-50eeb87effbf.jpg)

![Final Report of GSoC pptx (7)](https://user-images.githubusercontent.com/8393063/189003236-a9c87852-7168-4c8a-8239-944ce0170ec8.jpg)

![Final Report of GSoC pptx (8)](https://user-images.githubusercontent.com/8393063/189003334-5bea41d9-b80c-4e91-8805-375fcabdd107.jpg)

![Final Report of GSoC pptx (13)](https://user-images.githubusercontent.com/8393063/189556153-948bdbf9-9e03-4695-95e7-d270c38f5fe1.jpg)
