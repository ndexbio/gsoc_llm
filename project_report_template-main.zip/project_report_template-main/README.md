# Template for Project Reports

Review and edit 

* _config.yml
* contributors.csv 
* index.md 
* Example reports in _reports
* Edit this README with a short project description

# Template Source

https://github.com/cannin/project_report_template
